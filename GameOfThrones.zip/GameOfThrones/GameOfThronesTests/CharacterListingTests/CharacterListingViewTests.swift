//
//  CharacterListingViewTests.swift
//  GameOfThronesTests
//
//  Created by RAHUL CK on 1/13/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import XCTest
@testable import GameOfThrones

class CharacterListingViewTests: XCTestCase {
    var characterListingVC:CharacterListingViewController!
    var expectation:XCTestExpectation?
    
    override func setUp() {
        characterListingVC = CharacterListingViewController.instantiateViewController()
        
        let book = GTBook(url: "", name: "", isbn: nil, authors: [], numberOfPages: 9, publisher: "", country: "", mediaType: "", released: "", characters: [], povCharacters: nil)
        
        CharacterListingViewRouter.createCharacterListViewModule(characterListviewRef: characterListingVC, with: book)
    }
    
    // MARK: Base tests
    
    func testWhetherCharacterListingModuleConfiguredCorrectly() {
        XCTAssertNotNil(characterListingVC.presentor, "Presenter is nil")
        XCTAssertNotNil(characterListingVC.presentor?.interactor, "Interactor is nil")
        XCTAssertNotNil(characterListingVC.presentor?.router, "Router is nil")
    }
    //MARK:- Character Listing Module Integration Test
    func testCharacterListingViewDidLoadAndDataFetching()  {
        expectation = XCTestExpectation(description: "Fetch homedata")
        characterListingVC.presentor?.view = self
        characterListingVC.presentor?.viewDidLoad()
        wait(for: [expectation!], timeout: 20.0)
    }
    override func tearDown() {
        expectation?.fulfill()
        expectation = nil
    }
}
extension CharacterListingViewTests:CharacterListViewProtocol {
    func showCharacters(with characters: [GTCharacter]) {
        // Testing whether api is giving charcter list
        XCTAssert(characters.count > 0, "Empty character list")
        
        // For testing whether all madatory details getting from API
        for character in characters {
            XCTAssertFalse(character.displayName.isEmpty, "Name and alias are empty")
        }
        expectation?.fulfill()
    }
    func showAPIError(message:String) {
        XCTFail(message)
        expectation?.fulfill()
    }
}
