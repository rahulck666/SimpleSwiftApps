//
//  HomeViewControllerTests.swift
//  GameOfThronesTests
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import XCTest
@testable import GameOfThrones

class HomeViewTests: XCTestCase {
    
    var homeViewController:HomeViewController!
    var expectation:XCTestExpectation?
    override func setUp() {
        homeViewController = HomeViewController.instantiateViewController()
        HomeViewRouter.createHomeViewModule(homeviewRef: homeViewController)
    }
    // MARK: Base tests
    
    func testWhetherHomeModuleConfiguredCorrectly() {
        XCTAssertNotNil(homeViewController.presentor, "Presenter is nil")
        XCTAssertNotNil(homeViewController.presentor?.interactor, "Interactor is nil")
        XCTAssertNotNil(homeViewController.presentor?.router, "Router is nil")
    }
    //MARK:- Home Module Integration Test
    func testHomeViewDidLoadAndHomeDataFetching()  {
        expectation = XCTestExpectation(description: "Fetch homedata")
        homeViewController.presentor?.view = self
        homeViewController.presentor?.viewDidLoad()
        wait(for: [expectation!], timeout: 20.0)
    }
    
    
    override func tearDown() {
        expectation?.fulfill()
        expectation = nil
    }
    
}
extension HomeViewTests:HomeViewProtocol {
    func showBooks(with books: [GTBook]) {
        
        // Testing whether api is giving books
        XCTAssert(books.count > 0, "Empty Books")
        
        // For testing whether all madatory details getting from API
        for book in books {
            XCTAssertFalse(book.name.isEmpty, "Book with empty book name")
            XCTAssert(book.numberOfPages > 0, "Book with invalid number of page")
            XCTAssertNotNil(book.authors, "Book with no authors")
        }
        expectation?.fulfill()
        
    }
    func showAPIError(message:String) {
        XCTFail(message)
        expectation?.fulfill()
    }
}
