//
//  APITests.swift
//  GameOfThronesTests
//
//  Created by RAHUL CK on 1/13/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import XCTest
@testable import GameOfThrones


class APITests: XCTestCase {

    var expectation:XCTestExpectation?
   
    override func setUp() {
    }
    
    // Testing homedata API
    func testGetHomeDataAPI() {
        self.expectation = XCTestExpectation(description: "Fetching HomeData....")
        let homeViewInteractor =  HomeViewInteractor(presenter:self)
        homeViewInteractor.fetchBookList()
        wait(for: [self.expectation!], timeout: 20)
        
    }
    // Testing get character list API
    func testGetCharacterListAPI() {
        self.expectation = XCTestExpectation(description: "Fetching Characters....")
        let characterListingInteracter =  CharacterListingViewInteractor(presenter: self)
        let book = GTBook(url: "", name: "", isbn: nil, authors: [], numberOfPages: 9, publisher: "", country: "", mediaType: "", released: "", characters: [], povCharacters: nil)
        characterListingInteracter.fetchCharacterList(book: book)
        wait(for: [self.expectation!], timeout: 20)
        
    }
    override func tearDown() {
        expectation = nil
    }

}
extension APITests: HomeViewOutputInteractorProtocol {
    func bookListDidFetch(books: [GTBook]?) {

        // Testing whether api is giving books
        XCTAssertNotNil(books, "HomeAPI Failed")
        
        guard let books = books else { return }
        
        // For testing whether all madatory details getting from API
        for book in books {
            XCTAssertFalse(book.name.isEmpty, "Book with empty book name")
            XCTAssert(book.numberOfPages > 0, "Book with invalid number of page")
            XCTAssertNotNil(book.authors, "Book with no authors")
        }
        expectation?.fulfill()

    }
    
    func bookListDidFetchFailed(error: Error?) {
        
        XCTFail((error as? APIError)?.localizedDescription ?? "Home API Failed")
        expectation?.fulfill()
    }
    
    
}
extension APITests:CharacterListViewOutputInteractorProtocol {
    func characterListDidFetch(characters: [GTCharacter]?) {
        
        // Testing whether getCharacterListing API working or not
        XCTAssertNotNil(characters, "GetCharacter Listing API Failed")
        
        guard let characters = characters else { return }
        
        // For testing whether all madatory details getting from API
        for character in characters {
            XCTAssertFalse(character.displayName.isEmpty, "character name and alias are empty")
           
        }
        expectation?.fulfill()
    }
    
    func characterListDidFetchFailed(error: Error?) {
        XCTFail(error?.localizedDescription ?? "GetCharacter Listing API Failed")
        expectation?.fulfill()
    }
    
    
}
