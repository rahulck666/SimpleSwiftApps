//
//  CharacterDetailTest.swift
//  GameOfThronesTests
//
//  Created by RAHUL CK on 1/13/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import XCTest
@testable import GameOfThrones

class CharacterDetailTest: XCTestCase {
    
    var characterDetailVC:CharacterDetailViewController!
    var expectation:XCTestExpectation?
    override func setUp() {
        characterDetailVC = CharacterDetailViewController.instantiateViewController()
        
        let character = GTCharacter(url: "", name: "name", gender: "male", culture: "", born: "", died: "", father: "", mother: "", spouse: "", aliases: [])
        CharacterDetailRouter.createCharacterDetailViewModule(characterDetailViewRef: characterDetailVC, character: character)
    }
    // MARK: Base tests
    
    func testWhetherCharacterDetailModuleConfiguredCorrectly() {
        XCTAssertNotNil(characterDetailVC.presenter, "Presenter is nil")
        XCTAssertNotNil(characterDetailVC.presenter?.router, "Router is nil")
        //No interactor configured for character detail since no API call
      //  XCTAssertNotNil(characterDetailVC.presenter?.interactor, "Interactor is nil")

    }
    override func tearDown() {
    }
    
}
