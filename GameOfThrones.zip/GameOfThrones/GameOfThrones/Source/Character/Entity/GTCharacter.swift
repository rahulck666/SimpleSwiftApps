//
//  GTCharacter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation


struct GTCharacter:Decodable {
    let url:String
    let name:String
    let gender:String
    let culture:String
    let born:String
    let died:String
    let father:String
    let mother:String
    let spouse:String
    let aliases:[String]
    
    var displayName:String {
        get {
            if name.isEmpty {
                return aliases.first ?? ""
            }
            else {
                return name
            }
            
        }
    }
    
    
    
    
}
