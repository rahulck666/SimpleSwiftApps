//
//  CharacterListingViewInteractor.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterListingViewInteractor: CharacterListViewInputInteractorProtocol {
    
    weak var presenter: CharacterListViewOutputInteractorProtocol?
    var apiManager = GTAPIManager()
    init(presenter:CharacterListViewOutputInteractorProtocol) {
        self.presenter = presenter
    }
    
    /**
     Fetch all characters in a book
     */
    func fetchCharacterList(book:GTBook) {
        apiManager.fetchCharacters(book:"") { (response) in
            switch response {
            case let .success(characters):
                self.presenter?.characterListDidFetch(characters: characters)
                break
            case let .failure(error):
                self.presenter?.characterListDidFetchFailed(error: error)
                break
            }
        }
    }
    
    
}
