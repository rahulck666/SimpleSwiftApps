//
//  CharacterDetailViewProtocols.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

protocol CharacterDetailViewProtocol: class {
    // PRESENTER -> VIEW
    func showCharacter(with character:GTCharacter)
    func showAPIError(message:String)
}

protocol CharacterDetailViewPresenterProtocol: class {
    //View -> Presenter
    var interactor: CharacterDetailViewInputInteractorProtocol? {get set}
    var view: CharacterDetailViewProtocol? {get set}
    var router: CharacterDetailViewRouterProtocol? {get set}
    func viewDidLoad()
}

protocol CharacterDetailViewInputInteractorProtocol: class {
    var presenter: CharacterDetailViewOutputInteractorProtocol? {get set}
    //Presenter -> Interactor
}

protocol CharacterDetailViewOutputInteractorProtocol: class {
    //Interactor -> Presenter
}

protocol CharacterDetailViewRouterProtocol: class {
    //Presenter -> Router
    static func createCharacterDetailViewModule(characterDetailViewRef: CharacterDetailViewController,character:GTCharacter)
}
