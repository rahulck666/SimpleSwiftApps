//
//  CharacterListViewProtocol.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

protocol CharacterListViewProtocol: class {
    // PRESENTER -> VIEW
    func showCharacters(with characters: [GTCharacter])
    func showAPIError(message:String)
}

protocol CharacterListViewPresenterProtocol: class {
    //View -> Presenter
    var interactor: CharacterListViewInputInteractorProtocol? {get set}
    var view: CharacterListViewProtocol? {get set}
    var router: CharacterListViewRouterProtocol? {get set}
    func viewDidLoad()
    func showCharacterSelection(with character: GTCharacter, from view: UIViewController)
}

protocol CharacterListViewInputInteractorProtocol: class {
    var presenter: CharacterListViewOutputInteractorProtocol? {get set}
    //Presenter -> Interactor
    func fetchCharacterList(book:GTBook)
}

protocol CharacterListViewOutputInteractorProtocol: class {
    //Interactor -> Presenter
    func characterListDidFetch(characters: [GTCharacter]?)
    func characterListDidFetchFailed(error: Error?)
}

protocol CharacterListViewRouterProtocol: class {
    //Presenter -> Router
    func pushToCharacterDetail(from view: UIViewController,character:GTCharacter)
    static func createCharacterListViewModule(characterListviewRef: CharacterListingViewController,with book:GTBook)
}
