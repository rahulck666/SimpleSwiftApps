//
//  CharacterDetailRouter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterDetailRouter: CharacterDetailViewRouterProtocol {
    
    /**
     Assemble character detail
     */
    static func createCharacterDetailViewModule(characterDetailViewRef: CharacterDetailViewController,character:GTCharacter) {
        
        let presenter = CharacterDetailViewPresenter()
        presenter.character = character
        presenter.router = CharacterDetailRouter()
        presenter.character = character
        presenter.view = characterDetailViewRef
        characterDetailViewRef.presenter = presenter
    }
    
    
}
