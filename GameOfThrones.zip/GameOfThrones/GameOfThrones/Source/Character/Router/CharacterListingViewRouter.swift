//
//  CharacterListingViewRouter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterListingViewRouter: CharacterListViewRouterProtocol {
    
    /**
     Navigate to character detail
     */
    func pushToCharacterDetail(from view: UIViewController,character:GTCharacter) {
        
        let controller = CharacterDetailViewController.instantiateViewController()
        CharacterDetailRouter.createCharacterDetailViewModule(characterDetailViewRef: controller, character: character)
        view.navigationController?.pushViewController(controller, animated: true)
        
    }
    /**
     Assemble character listing module
     */
    static func createCharacterListViewModule(characterListviewRef: CharacterListingViewController,with book:GTBook) {
        
        let presenter = CharacterListingViewPresenter()
        presenter.selectedBook = book
        presenter.router = CharacterListingViewRouter()
        presenter.view = characterListviewRef
        presenter.interactor = CharacterListingViewInteractor(presenter: presenter)
        characterListviewRef.presentor = presenter
        
    }
    
    
}
