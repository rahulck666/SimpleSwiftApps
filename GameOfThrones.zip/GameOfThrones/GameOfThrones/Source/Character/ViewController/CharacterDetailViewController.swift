//
//  CharacterDetailViewController.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterDetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var bornLabel: UILabel!
    @IBOutlet weak var fatherOfLabel: UILabel!
    @IBOutlet weak var motherOfLabel: UILabel!
    @IBOutlet weak var spouceLabel: UILabel!
    @IBOutlet weak var diedLabel: UILabel!
    @IBOutlet weak var noResponseLabel: UILabel!
    var presenter:CharacterDetailViewPresenterProtocol?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.viewDidLoad()
        initialSetup()
        
    }
    
    /**
     Instantiate a controller
     */
    static func instantiateViewController() -> CharacterDetailViewController {
        return UIStoryboard.home().instantiateViewController(withIdentifier:
            CharacterDetailViewController.className) as! CharacterDetailViewController
    }
    
    /**
     Doing the initial setup for the controller
     */
    func initialSetup()  {
        self.navigationItem.title = GTLocalisationConstants.characterDetail
    }
    
    
}
//MARK:- Presenter protocols
extension CharacterDetailViewController:CharacterDetailViewProtocol {
    func showCharacter(with character: GTCharacter) {
        nameLabel.text = character.displayName
        
        genderLabel.text = GTLocalisationConstants.gender +
            (character.gender.isEmpty ? GTLocalisationConstants.nill : character.gender)
        
        bornLabel.text = GTLocalisationConstants.born
            + (character.born.isEmpty ? GTLocalisationConstants.nill : character.born)
        
        fatherOfLabel.text = GTLocalisationConstants.father
            + (character.father.isEmpty ? GTLocalisationConstants.nill : character.born)
        
        motherOfLabel.text = GTLocalisationConstants.mother
            + (character.mother.isEmpty ? GTLocalisationConstants.nill : character.born)
        
        spouceLabel.text = GTLocalisationConstants.spouce
            + (character.spouse.isEmpty ? GTLocalisationConstants.nill : character.born)
        
        diedLabel.text = GTLocalisationConstants.died
            + (character.died.isEmpty ? GTLocalisationConstants.nill : character.born)
    }
    
    func showAPIError(message: String) {
        self.noResponseLabel.text = message
    }
    
}
