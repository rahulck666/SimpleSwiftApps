//
//  CharacterListingViewController.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterListingViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noResponseLabel: UILabel!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    var characters:[GTCharacter]?
    var presentor:CharacterListViewPresenterProtocol?
    override func viewDidLoad() {
        super.viewDidLoad()
        presentor?.viewDidLoad()
        initialSetup()
        activityIndicatorView.startAnimating()
    }
    
    /**
     Instantiate a controller
     */
    static func instantiateViewController() -> CharacterListingViewController {
        return UIStoryboard.home().instantiateViewController(withIdentifier:
            CharacterListingViewController.className) as! CharacterListingViewController
    }
    
    /**
     Doing the initial setup for the controller
     */
    func initialSetup()  {
        self.tableView.register(CharacterViewCell.self, forCellReuseIdentifier: CharacterViewCell.className)
        self.tableView.tableFooterView = UIView.init(frame: CGRect.zero)
        self.navigationItem.title = GTLocalisationConstants.characters
        self.tableView.accessibilityIdentifier = GTAccessibilityIdentifier.characterListingTableView
        
    }

}
//MARK:- Presenter Protocols
extension CharacterListingViewController:CharacterListViewProtocol {
    func showCharacters(with characters: [GTCharacter]) {
        self.characters = characters
        activityIndicatorView.stopAnimating()
        tableView.reloadData()
    }
    
    func showAPIError(message: String) {
        activityIndicatorView.stopAnimating()
    }
}
//MARK:- TableView Delegate and Datasource
extension CharacterListingViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return characters?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: CharacterViewCell.className, for: indexPath)
        guard let character = characters?[indexPath.row] else {
            return cell
        }
        cell.textLabel?.text = character.displayName
        cell.detailTextLabel?.text = character.culture
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.tableView.deselectRow(at: indexPath, animated: true)
        if let character = characters?[indexPath.row] {
            presentor?.showCharacterSelection(with: character, from: self)
        }
    }
}
