//
//  CharacterListingViewPresenter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterListingViewPresenter: CharacterListViewPresenterProtocol,CharacterListViewOutputInteractorProtocol {
    
    var interactor: CharacterListViewInputInteractorProtocol?
    weak var view: CharacterListViewProtocol?
    var router: CharacterListViewRouterProtocol?
    var selectedBook:GTBook!
    
    /**
     Character listing success call back
     */
    func characterListDidFetch(characters: [GTCharacter]?) {
        if let characters = characters {
            view?.showCharacters(with: characters)
        }
        else {
            view?.showAPIError(message: GTLocalisationConstants.somethingWentWrong)
        }
    }
    /**
     Character listing failed call back
     */
    func characterListDidFetchFailed(error: Error?) {
        view?.showAPIError(message: error?.localizedDescription ?? GTLocalisationConstants.somethingWentWrong )
        
    }
    /**
     This will get called when viewDidLoad of corresponding ViewController is called
     */
    func viewDidLoad() {
        interactor?.fetchCharacterList(book: selectedBook)
    }
    /**
     This will get called when a character is selected from a list
     */
    func showCharacterSelection(with character: GTCharacter, from view: UIViewController) {
        router?.pushToCharacterDetail(from: view, character: character)
    }
}
