//
//  CharacterDetailViewPresenter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterDetailViewPresenter: CharacterDetailViewPresenterProtocol {
    
    
    var interactor: CharacterDetailViewInputInteractorProtocol?
    var character:GTCharacter?
    weak var view: CharacterDetailViewProtocol?
    var router: CharacterDetailViewRouterProtocol?
    
    /**
     This will get called when ViewDidLoad of a view controller get called
     */
    func viewDidLoad() {
        if let character = self.character {
            view?.showCharacter(with: character)
        }
        else {
            view?.showAPIError(message: GTLocalisationConstants.somethingWentWrong)
        }
        
    }
    
    
    
}
