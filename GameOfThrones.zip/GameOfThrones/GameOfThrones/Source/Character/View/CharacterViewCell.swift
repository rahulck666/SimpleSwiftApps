//
//  CharacterViewCell.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/12/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class CharacterViewCell: UITableViewCell {
    
}
