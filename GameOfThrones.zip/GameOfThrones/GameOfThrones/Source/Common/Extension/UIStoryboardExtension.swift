
//  UIStoryboardExtension.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/10/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

extension UIStoryboard {
    /// return main story board
    class func home() -> UIStoryboard {
        return UIStoryboard(name: GTStoryboardConstants.home, bundle: nil)
    }
}
