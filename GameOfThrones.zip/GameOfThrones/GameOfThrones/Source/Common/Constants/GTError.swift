//
//  GTError.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/10/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation
