//
//  GTConstants.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/10/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

/// to hold story board name constantsst
struct GTStoryboardConstants {
    static let home = "Home"    
}
struct GTLocalisationConstants {
    static let gameOfThrones = "Game of Thrones"
    static let by = "By"
    static let pages = "Pages"
    static let somethingWentWrong = "Something went wrong!"
    static let noBookFound = "No Books found!"
    static let books = "Books"
    static let characters = "Characters"
    static let characterDetail = "Character Detail"
    static let gender = "Gender "
    static let spouce = "Spouce of "
    static let father = "Father of "
    static let mother = "Mother of "
    static let died = "Died on "
    static let born = "Born on "
    static let nill = "Nil"
}

struct GTAccessibilityIdentifier {
    static let homeTableView = "HomeTableView"
    static let characterListingTableView = "characterListingTableView"
    static let characterDetailNameLabel = "characterDetailNameLabel"

}
