//
//  HomeViewRouter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class HomeViewRouter: HomeViewRouterProtocol {
    
    /**
     Assemble home module
     */
    static func createHomeViewModule(homeviewRef: HomeViewController) {
        let presenter:HomeViewPresenterProtocol & HomeViewOutputInteractorProtocol = HomeViewPresenter()
        presenter.router = HomeViewRouter()
        presenter.view = homeviewRef
        presenter.interactor = HomeViewInteractor(presenter: presenter)
        homeviewRef.presentor = presenter
    }
    
    /**
     Navigate to character listing
     */
    func pushToCharacterListing(from view: UIViewController,book:GTBook) {
        let controller = CharacterListingViewController.instantiateViewController()
        CharacterListingViewRouter.createCharacterListViewModule(characterListviewRef: controller, with: book)
        view.navigationController?.pushViewController(controller, animated: true)
        
    }
    
}
