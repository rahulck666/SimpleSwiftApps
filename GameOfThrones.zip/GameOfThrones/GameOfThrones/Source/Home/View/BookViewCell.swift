//
//  BookViewCell.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class BookViewCell: UITableViewCell {
    
    @IBOutlet weak var noOfPagesLabel: UILabel!
    @IBOutlet weak var mediaTypeLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var bookImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
