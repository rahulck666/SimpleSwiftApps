//
//  HomeViewPresenter.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class HomeViewPresenter:HomeViewPresenterProtocol,HomeViewOutputInteractorProtocol {
    
    var router: HomeViewRouterProtocol?
    var interactor: HomeViewInputInteractorProtocol?
    weak var view: HomeViewProtocol?
    
    func viewDidLoad() {
        interactor?.fetchBookList()
        
    }
    /**
     This will get called when a book is selected from a list
     */
    func showBookSelection(with book: GTBook, from view: UIViewController) {
        router?.pushToCharacterListing(from: view, book: book)
    }
    /**
     Fetch book list success call back
     */
    func bookListDidFetch(books: [GTBook]?) {
        if let books = books {
            self.view?.showBooks(with: books)
        }
        else {
            self.view?.showAPIError(message: GTLocalisationConstants.noBookFound)
        }
    }
    /**
     Fetch book list failed call back
     */
    func bookListDidFetchFailed(error: Error?) {
        self.view?.showAPIError(message: error?.localizedDescription ?? GTLocalisationConstants.somethingWentWrong)
        
    }
    
}
