//
//  HomeInteractor.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

class HomeViewInteractor: HomeViewInputInteractorProtocol {
    
    weak var presenter: HomeViewOutputInteractorProtocol?
    var apiManager = GTAPIManager()
    
    init(presenter:HomeViewOutputInteractorProtocol) {
        self.presenter = presenter
    }
    
    /**
     Fetch all books
     */
    func fetchBookList() {
        apiManager.fetchHomeData { (response) in
            switch response {
            case let .failure(error):
                self.presenter?.bookListDidFetchFailed(error: error)
                break
            case let .success(books):
                self.presenter?.bookListDidFetch(books: books)
                break
            }
        }
    }
    
    
}
