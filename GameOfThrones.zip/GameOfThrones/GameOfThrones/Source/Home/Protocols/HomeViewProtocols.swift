//
//  HomeViewProtocols.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

protocol HomeViewProtocol: class {
    // PRESENTER -> VIEW
    func showBooks(with books: [GTBook])
    func showAPIError(message:String)
}

protocol HomeViewPresenterProtocol: class {
    //View -> Presenter
    var interactor: HomeViewInputInteractorProtocol? {get set}
    var view: HomeViewProtocol? {get set}
    var router: HomeViewRouterProtocol? {get set}
    func viewDidLoad()
    func showBookSelection(with book: GTBook, from view: UIViewController)
}

protocol HomeViewInputInteractorProtocol: class {
    var presenter: HomeViewOutputInteractorProtocol? {get set}
    //Presenter -> Interactor
    func fetchBookList()
}

protocol HomeViewOutputInteractorProtocol: class {
    //Interactor -> Presenter
    func bookListDidFetch(books: [GTBook]?)
    func bookListDidFetchFailed(error: Error?)
}

protocol HomeViewRouterProtocol: class {
    //Presenter -> Router
    func pushToCharacterListing(from view: UIViewController,book:GTBook)
    static func createHomeViewModule(homeviewRef: HomeViewController)
}
