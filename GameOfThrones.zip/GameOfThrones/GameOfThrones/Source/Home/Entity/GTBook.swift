//
//  Book.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

struct GTBook: Decodable {
    let url:String?
    let name:String
    let isbn:String?
    let authors:[String]
    let numberOfPages:Int
    let publisher:String
    let country:String
    let mediaType:String
    let released:String
    let characters:[String]
    let povCharacters:[String]?
    
}
