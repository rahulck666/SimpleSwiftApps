//
//  HomeViewController.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/10/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noResponseLabel: UILabel!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    var presentor:HomeViewPresenterProtocol?
    var books:[GTBook]?
    
    /**
    Instantiate a controller
     */
    static func instantiateViewController() -> HomeViewController {
        return UIStoryboard.home().instantiateViewController(withIdentifier:
            HomeViewController.className) as! HomeViewController
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        HomeViewRouter.createHomeViewModule(homeviewRef: self)
        initialSetup()
        activityIndicatorView.startAnimating()
        presentor?.viewDidLoad()
    }
    /**
     Doing the initial setup for the controller
     */
    func initialSetup()  {
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.navigationItem.title = GTLocalisationConstants.books
        self.tableView.accessibilityIdentifier = GTAccessibilityIdentifier.homeTableView
        
    }
}
//MARK:- Presenter protocols
extension HomeViewController:HomeViewProtocol {
    
    func showBooks(with books: [GTBook]) {
        self.noResponseLabel.isHidden = true
        self.books = books
        self.activityIndicatorView.stopAnimating()
        self.tableView.reloadData()
    }
    func showAPIError(message:String) {
        self.noResponseLabel.isHidden = false
        self.noResponseLabel.text = message
        self.activityIndicatorView.stopAnimating()
        
    }
    
}
//MARK:- TableView Delegate and Datasource
extension HomeViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: BookViewCell.className, for: indexPath)
        guard let book = books?[indexPath.row] else {
            return cell
        }
        (cell as? BookViewCell)?.nameLabel.text = book.name
        (cell as? BookViewCell)?.authorLabel.text = "\(GTLocalisationConstants.by) \(book.authors.first ?? "")"
        (cell as? BookViewCell)?.noOfPagesLabel.text = "\(book.numberOfPages) \(GTLocalisationConstants.pages)"
        (cell as? BookViewCell)?.mediaTypeLabel.text = book.mediaType
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.tableView.deselectRow(at: indexPath, animated: true)
        if let book = books?[indexPath.row] {
            presentor?.showBookSelection(with: book, from: self)
        }
    }
}

