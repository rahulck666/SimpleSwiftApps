//
//  GTAPIManager.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

class GTAPIManager: BaseAPIManager {
    
    let session: URLSession
    
    init(configuration: URLSessionConfiguration) {
        self.session = URLSession(configuration: configuration)
    }
    
    convenience init() {
        self.init(configuration: .default)
    }
    
    /**
     Fetch home data,books
     */
    func fetchHomeData(completion: @escaping (APIResponse<[GTBook]?, APIError>) -> Void) {
        
        let endpoint = GTFeed.home
        var request = endpoint.request
        request.method = HTTPMethod.get
        print(request.method ?? "")
        fetch(with: request, decode: { json -> [GTBook]? in
            guard let bookFeedResult = json as? [GTBook] else { return  nil }
            return bookFeedResult
        }, completion: completion)
    }
    /**
     Fetch all characters in a book
     */
    func fetchCharacters(book:String,completion: @escaping (APIResponse<[GTCharacter]?, APIError>) -> Void) {
        
        let endpoint = GTFeed.characterListing(book: book)
        let request = endpoint.request
        fetch(with: request, decode: { json -> [GTCharacter]? in
            guard let bookFeedResult = json as? [GTCharacter] else { return  nil }
            return bookFeedResult
        }, completion: completion)
    }
}
