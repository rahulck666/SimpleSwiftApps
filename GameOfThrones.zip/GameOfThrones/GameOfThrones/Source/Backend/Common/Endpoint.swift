//
//  EndPoints.swift
//  GameOfThrones
//
//  Created by RAHUL CK on 1/11/19.
//  Copyright © 2019 UST Global. All rights reserved.
//

import Foundation

protocol Endpoint {
    var base: String { get }
    var path: String { get }
    var method: HTTPMethod { get }
}

extension Endpoint {
    
    var apiKey: String {
        return ""
    }
    
    var urlComponents: URLComponents {
        var components = URLComponents(string: base)!
        components.path = path
        components.query = apiKey
        return components
    }
    
    var request: URLRequest {
        let url = urlComponents.url!
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        return request
    }
}

enum GTFeed {
    case home
    case characterListing(book:String)
    case characterDetail(characterId:String)
}

extension GTFeed: Endpoint {
    var method: HTTPMethod {
        return .get
    }
    
    var base: String {
        return "https://anapioficeandfire.com"
    }
    
    var path: String {
        switch self {
            
        case .home:
            return "/api/books"
            
        case let .characterListing(book):
            // Wrong API is given.This should be list of characters not books.
            //  return "/api/books/" + book
            return "/api/characters/" + book
            
        case let .characterDetail(characterId):
            return "/api/characters/" + characterId
        }
    }
}


